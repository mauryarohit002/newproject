<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Ocean extends CI_Controller {

	
	public function index()
	{
		$this->load->view('index');
	}

	public function about()
	{
		$this->load->view('about-us');
	}
	public function men()
	{
		$this->load->view('men');
	}
	public function women()
	{
		$this->load->view('women');
	}
	public function product()
	{
		$this->load->view('product');
	}
	public function contact()
	{
		$this->load->view('contact');
	}
	// public function index()
	// {
	// 	$this->load->view('index');
	// }
}
