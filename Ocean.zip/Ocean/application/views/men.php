
<?php require_once'head.php'; ?>
        <div class="canvas-wrapper">
            <div class="content-wrap">
                <div class="content">
                    <!-- header start -->
                    <?php require_once'header.php'; ?>
                    <!-- header end -->
                    
                    <!-- breadcrumbs start -->
                    <div class="breadcrumbs-area breadcrumb-bg ptb-100">
                        <div class="container">
                            <div class="breadcrumbs text-center">
                                <h2 class="breadcrumb-title">men's footwear</h2>
                                <ul>
                                    <li>
                                        <a class="active" href="<?php echo base_url('ocean/index') ?>">Home</a>
                                    </li>
                                    <li>shop</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- breadcrumbs area end -->
                    <!-- login area end -->
                    <div class="shop-page-area ptb-100">
                        <div class="container">
                            <div class="row">
                                
                                <div class="col-md-12">
                                    <div class="blog-wrapper shop-page-mrg">
                                        <div class="tab-menu-product">
                                            <div class="tab-product">
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="grid"> 
                                                        <div class="row">
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">PC Headphone</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men1.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">Table Lamp</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men2.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">Table Fan</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men3.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">Air Conditionar</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men4.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">Soundbox</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men5.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">Micro Woven</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men6.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">Air Cooler</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men7.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">Washing machine</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men8.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">Wall Watch</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men9.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">IPS Box</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men10.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">Charger</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-6">
                                                                <div class="single-shop mb-40">
                                                                    <div class="shop-img">
                                                                        <a href="#"><img src="<?php echo base_url('assets/img/new-collection/men11.jpg') ?>" alt="" /></a>
                                                                        <div class="shop-quick-view">
                                                                            <a href="#" class="model" data-toggle="modal" data-target="#quick-view" title="Quick View">
                                                                                <i class="pe-7s-look"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div class="button-group">
                                                                            <a href="#" title="Add to Cart">
                                                                                <i class="pe-7s-cart"></i>
                                                                                add to cart
                                                                            </a>
                                                                            <a class="wishlist" href="#" title="Wishlist">
                                                                                <i class="pe-7s-like"></i>
                                                                                Wishlist
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="shop-text-all">
                                                                        <div class="title-color fix">
                                                                            <div class="shop-title f-left">
                                                                                <h3><a href="#">Monitor</a></h3>
                                                                            </div>
                                                                            <span class="price f-right">
                                                                                <span class="new">$120.00</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="fix">
                                                                            <span class="f-left">Footwear</span>
                                                                        </div>
                                                                    </div>                                  
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

<script type="text/javascript">

    $('.model').on('click',function(){
        $('#sin-pro-1').find('img').remove();
        var sr=$(this).parent().parent().find('img').attr('src');
        $('#sin-pro-1').append('<img src="'+sr+'" alt="" />');

         

            // $('.rom')
        $(function(){
            // tile mouse actions
            $('.zoom').on('mouseover', function(){
              $(this).children('.photo').css({'transform': 'scale(2)'});
              // $(this).children('.photo').css({'transform': 'scale('+ $(this).attr('data-scale') +')'});
            })
            $('.zoom').on('mouseout', function(){
              $(this).children('.photo').css({'transform': 'scale(1)'});
            })
            $('.zoom').on('mousemove', function(e){
              $(this).children('.photo').css({'transform-origin': ((e.pageX - $(this).offset().left) / $(this).width()) * 100 + '% ' + ((e.pageY - $(this).offset().top) / $(this).height()) * 100 +'%'});
            })
            // tiles set up
            $('.zoom').each(function(){
              $(this)
                // add a photo container
                .append('<div class="photo"></div>')
                .children('.photo').css({'background-image': 'url('+ $(this).find('img').attr('src') +')'});
            })
        });

    });    
</script>

<style type="text/css">
    .photo {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        transition: transform .5s ease-out;
    }
    .zoom{
        position: relative;
        float: left;
        width: 100%;
        height: 100%;
        overflow: hidden;
    }
</style>                       
                    
                    
                   <!-- quick view start -->
                    <div class="quick-view modal fade in" id="quick-view">
                        <div class="container">
                            <div class="row">
                                <div id="view-gallery">
                                    <div class="col-xs-12">
                                        <div class="d-table">
                                            <div class="d-tablecell">
                                                <div class="modal-dialog">
                                                    <div class="main-view modal-content">
                                                        <div class="modal-footer" data-dismiss="modal">
                                                            <span>x</span>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-xs-12 col-sm-5">
                                                                <div class="quick-image">
                                                                    <div class="single-quick-image tab-content text-center">
                                                                        <div class="tab-pane zoom fade in active" id="sin-pro-1">
                                                                            <!-- <img src="https://nahartheme.com/tf/jerin-preview/jerin/assets/img/shop/q1.jpg" alt="" /> -->
                                                                        </div>
                                                                        
                                                                    </div>
                                                                    <!-- <div class="quick-thumb">
                                                                        <div class="nav nav-tabs">
                                                                            <ul>
                                                                                <li><a data-toggle="tab" href="#sin-pro-1"> <img src="https://nahartheme.com/tf/jerin-preview/jerin/assets/img/shop/q1.jpg" alt="quick view" /> </a></li>
                                                                                <li><a data-toggle="tab" href="#sin-pro-2"> <img src="https://nahartheme.com/tf/jerin-preview/jerin/assets/img/shop/q2.jpg" alt="quick view" /> </a></li>
                                                                                <li><a data-toggle="tab" href="#sin-pro-3"> <img src="https://nahartheme.com/tf/jerin-preview/jerin/assets/img/shop/q3.jpg" alt="quick view" /> </a></li>
                                                                                <li><a data-toggle="tab" href="#sin-pro-4"> <img src="https://nahartheme.com/tf/jerin-preview/jerin/assets/img/shop/q4.jpg" alt="quick view" /> </a></li>
                                                                            </ul>
                                                                        </div>
                                                                    </div> -->
                                                                </div>                          
                                                            </div>
                                                            <div class="col-xs-12 col-sm-7">
                                                                <div class="quick-right">
                                                                    <div class="quick-right-text">
                                                                        <h3><strong>PC Headphone</strong></h3>
                                                                        <div class="rating">
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star-half-o"></i>
                                                                            <i class="fa fa-star-o"></i>
                                                                        </div>
                                                                        <div class="amount">
                                                                            <h4>$65.00</h4>
                                                                        </div>
                                                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has beenin the stand ard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrames bled it make a type specimen book.</p>
                                                                        <div class="row m-p-b">
                                                                            <div class="col-sm-12 col-md-6">
                                                                                <div class="por-dse responsive-strok clearfix">
                                                                                    <ul>
                                                                                        <li><span>Availability</span><strong>:</strong> In stock</li>
                                                                                        <li><span>Condition</span><strong>:</strong> New product</li>
                                                                                        <li><span>Category</span><strong>:</strong> <a href="#">Men</a> <a href="#">Footwear</a> <a href="#">Shirt</a></li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-sm-12 col-md-6">
                                                                                <div class="por-dse color">
                                                                                    <ul>
                                                                                        <li><span>color</span><strong>:</strong> <a href="#">Red</a> <a href="#">Green</a> <a href="#">Blue</a></li>
                                                                                        <li><span>size</span><strong>:</strong>  <a href="#">SL</a> <a href="#">SX</a> <a href="#">M</a> <a href="#">XL</a></li>
                                                                                        <li><span>tag</span><strong>:</strong> <a href="#">Men</a> <a href="#">Footwear</a> <a href="#">Shirt</a></li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="dse-btn">
                                                                            <div class="row">
                                                                                <div class="col-sm-12 col-md-12">
                                                                                    <div class="por-dse clearfix">
                                                                                        <ul>
                                                                                            <li class="share-btn clearfix"><span>quantity</span>
                                                                                                <input class="input-text qty" name="qty" maxlength="12" value="1" title="Qty" type="text">
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col-sm-12 col-md-12">
                                                                                    <div class="por-dse add-to">
                                                                                        <a href="#">add to cart</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- quick view end -->
                <?php require_once'footer.php'; ?>