    <?php 
        require_once'head.php';

     ?>
        <div class="canvas-wrapper">
            <div class="content-wrap">
                <div class="content">
                    <!-- header start -->
                    <?php require_once'header.php'; ?>
                    <!-- header end -->
                    
                    <!-- breadcrumbs start -->
                    <div class="breadcrumbs-area breadcrumb-bg ptb-100">
                        <div class="container">
                            <div class="breadcrumbs text-center">
                                <h2 class="breadcrumb-title">contact us</h2>
                                <ul>
                                    <li>
                                        <a class="active" href="<?php echo base_url('ocean/index') ?>">Home</a>
                                    </li>
                                    <li>contact</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- breadcrumbs area end -->
                    <div id="contact-area" class="contact-area ptb-100 gray-bg">
                        <div class="container">
                            <div class="section-title text-center mb-70">
                                <h2>GET IN TOUCH <i class="fa fa-phone"></i></h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vel volutpat felis, eu condimentum massa. Pellentesque mollis eros vel mattis tempor.</p>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-lg-offset-2 col-lg-8 col-sm-12">
                                    <div class="row">
                                        <div class="col-md-5 col-lg-5 col-sm-5">
                                            <div class="contact-info-area">
                                                <ul>
                                                    <li>
                                                        <div class="contact-icon">
                                                            <i class="fa fa-phone"></i>
                                                        </div>
                                                        <div class="contact-address">
                                                            <h5>Phone</h5>
                                                            <span>+88 669 658 6586</span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="contact-icon">
                                                            <i class="fa fa-envelope-o"></i>
                                                        </div>
                                                        <div class="contact-address">
                                                            <h5>Email</h5>
                                                            <span><a href="#">themeglass@gmail.com</a></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="contact-icon">
                                                            <i class="fa fa-map-marker"></i>
                                                        </div>
                                                        <div class="contact-address">
                                                            <h5>Our Location</h5>
                                                            <span>Location Name,here.US</span>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-7 col-lg-7 col-sm-7">
                                            <div class="sent-message">
                                                <form class="contact_form" id="contact_form" action="#" method="post">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="main-input mb-10">
                                                                <input id="contact_name" name="name" placeholder="Name*" type="text">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="main-input mrg-eml mrg-contact mb-10">
                                                                <input id="contact_email" name="email" type="email" placeholder="Email*">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="text-leave2 mb-20">
                                                                <textarea name="message" id="contact_message" placeholder="Type Your Massage......."></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <button class="submit ripple-btn" type="submit" name="submit" id="contact_submit" data-complete-text="Well done!">Send Massage</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="contact-area-all">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3768.7443084561564!2d73.02584331437811!3d19.162666554223446!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7bf6dfd459ad5%3A0xc7873dcc89c75d3e!2sRashid+Compound%2C+Kausa%2C+Mumbra%2C+Thane%2C+Maharashtra+400612!5e0!3m2!1sen!2sin!4v1547968552979" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                    </div>
                    <!-- footer area start -->
                   <?php 
                        require_once'footer.php';
                    ?>