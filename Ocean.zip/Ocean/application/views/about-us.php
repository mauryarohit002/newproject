<?php 
    require_once'head.php';
 ?>
        <div class="canvas-wrapper">
            <div class="content-wrap">
                <div class="content">
                    <!-- header start -->
                    
                    <?php 
                        require_once'header.php';

                    ?>

                    <!-- header end -->
                    
                    <!-- breadcrumbs start -->
                    <div class="breadcrumbs-area breadcrumb-bg ptb-100">
                        <div class="container">
                            <div class="breadcrumbs text-center">
                                <h2 class="breadcrumb-title">about us</h2>
                                <ul>
                                    <li>
                                        <a class="active" href="<?php echo base_url('ocean/index') ?>">Home</a>
                                    </li>
                                    <li>about us</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- breadcrumbs area end -->
                    <!-- about start -->
                    <!-- <div class="about-area ptb-100">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="about-img">
                                        <img alt=""
                                            src="https://nahartheme.com/tf/jerin-preview/jerin/assets/img/banner/15.jpg">
                                        <a class="video-popup"
                                            href="https://www.youtube.com/watch?v=sYPTflDSY-k">
                                            <i class="fa fa-play"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <!-- about end -->
                    
                    <!-- about start -->
                    <div class="about-area pt-100 pb-70">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6 mb-30">
                                    <div class="about-all">
                                        <h2>Our Mission</h2>
                                        <p>Lorem ipsum dolor sit amet,
                                            consectetuer adipiscing elit.
                                            Aenean commodo ligula eget
                                            dolor. Aenean massa. Cum sociis
                                            natoque penatibus et magnis dis
                                            parturient montes, nascetur
                                            ridiculus mus. Donec quam felis,
                                            ultricies nec, pellentesque eu,
                                            pretium quis, sem. Nulla
                                            consequat massa quis enim.</p>
                                        <p>Lorem ipsum dolor sit amet,
                                            consectetuer adipiscing elit.
                                            Aenean commodo ligula eget
                                            dolor. Aenean massa. Cum sociis
                                            natoque penatibus et magnis dis
                                            parturient montes Cum sociis
                                            natoque penatibus et magnis dis
                                            parturient montes.</p>
                                        <p>Lorem ipsum dolor sit amet,
                                            consectetuer adipiscing elit.
                                            Aenean commodo ligula eget
                                            dolor. Aenean massa. Cum sociis
                                            natoque penatibus et magnis dis
                                            parturient montes Cum sociis
                                            natoque penatibus et magnis dis
                                            parturient montes.</p>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-30">
                                    <div class="about-img">
                                        <img alt="" src="https://nahartheme.com/tf/jerin-preview/jerin/assets/img/banner/mission.jpg">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- about end -->
                      
                    <!-- footer area start -->
                    <?php 
                    require_once'footer.php';

                     ?>