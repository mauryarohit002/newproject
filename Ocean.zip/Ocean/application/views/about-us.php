<?php 
    require_once'head.php';
 ?>
        <div class="canvas-wrapper">
            <div class="content-wrap">
                <div class="content">
                    <!-- header start -->
                    
                    <?php 
                        require_once'header.php';

                    ?>

                    <!-- header end -->
                    
                    <!-- breadcrumbs start -->
                    <div class="breadcrumbs-area breadcrumb-bg ptb-100">
                        <div class="container">
                            <div class="breadcrumbs text-center">
                                <h2 class="breadcrumb-title">about us</h2>
                                <ul>
                                    <li>
                                        <a class="active" href="index.html">Home</a>
                                    </li>
                                    <li>about us</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- breadcrumbs area end -->
                    <!-- about start -->
                    <!-- <div class="about-area ptb-100">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="about-img">
                                        <img alt=""
                                            src="https://nahartheme.com/tf/jerin-preview/jerin/assets/img/banner/15.jpg">
                                        <a class="video-popup"
                                            href="https://www.youtube.com/watch?v=sYPTflDSY-k">
                                            <i class="fa fa-play"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <!-- about end -->
                    <!-- service area start  -->
                    <div class="choose-us-skill-area pt-100 pb-70 gray-bg">
                        <div class="container">
                            <div class="section-title text-center mb-70">
                                <h2>
                                    Why Choose Us
                                    <i class="fa fa-star"></i>
                                </h2>
                                <p>Lorem ipsum dolor sit amet, consectetur
                                    adipiscing elit. Pellentesque vel
                                    volutpat felis, eu condimentum
                                    massa. Pellentesque mollis eros vel
                                    mattis tempor.</p>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="choose-us-area">
                                        <div class="choose-couses">
                                            <div class="single-choose col-md-4 mb-30">
                                                <div class="choose-icon">
                                                    <i class="pe-7s-cart"></i>
                                                </div>
                                                <div class="choose-text">
                                                    <h3>Good sales policy</h3>
                                                    <p>Lorem Ipsum is simply
                                                        dummy text of the
                                                        printing and
                                                        typesetting
                                                        industry. Lorem
                                                        Ipsum
                                                        the industry's
                                                        standard.</p>
                                                </div>
                                            </div>
                                            <div class="single-choose col-md-4 mb-30">
                                                <div class="choose-icon">
                                                    <i class="pe-7s-headphones"></i>
                                                </div>
                                                <div class="choose-text">
                                                    <h3>Customer care better</h3>
                                                    <p>Lorem Ipsum is simply
                                                        dummy text of the
                                                        printing and
                                                        typesetting
                                                        industry. Lorem
                                                        ipsum
                                                        printing.</p>
                                                </div>
                                            </div>
                                            <div class="single-choose col-md-4 mb-30">
                                                <div class="choose-icon">
                                                    <i class="pe-7s-cash"></i>
                                                </div>
                                                <div class="choose-text">
                                                    <h3>Flexible payment</h3>
                                                    <p>Lorem Ipsum is simply
                                                        dummy text of the
                                                        printing and
                                                        typesetting
                                                        industry. Lorem
                                                        Ipsum
                                                        has been the
                                                        industry's.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- service area end -->
                    <!-- about start -->
                    <div class="about-area pt-100 pb-70">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6 mb-30">
                                    <div class="about-all">
                                        <h2>Our Mission</h2>
                                        <p>Lorem ipsum dolor sit amet,
                                            consectetuer adipiscing elit.
                                            Aenean commodo ligula eget
                                            dolor. Aenean massa. Cum sociis
                                            natoque penatibus et magnis dis
                                            parturient montes, nascetur
                                            ridiculus mus. Donec quam felis,
                                            ultricies nec, pellentesque eu,
                                            pretium quis, sem. Nulla
                                            consequat massa quis enim.</p>
                                        <p>Lorem ipsum dolor sit amet,
                                            consectetuer adipiscing elit.
                                            Aenean commodo ligula eget
                                            dolor. Aenean massa. Cum sociis
                                            natoque penatibus et magnis dis
                                            parturient montes Cum sociis
                                            natoque penatibus et magnis dis
                                            parturient montes.</p>
                                        <p>Lorem ipsum dolor sit amet,
                                            consectetuer adipiscing elit.
                                            Aenean commodo ligula eget
                                            dolor. Aenean massa. Cum sociis
                                            natoque penatibus et magnis dis
                                            parturient montes Cum sociis
                                            natoque penatibus et magnis dis
                                            parturient montes.</p>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-30">
                                    <div class="about-img">
                                        <img alt="" src="https://nahartheme.com/tf/jerin-preview/jerin/assets/img/banner/mission.jpg">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- about end -->
                      
                    <!-- footer area start -->
                    <?php 
                    require_once'footer.php';

                     ?>